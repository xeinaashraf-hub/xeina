# Socialize Reel 01

Rendered deliverable: `output/socialize-reel-01.mp4`.

1080 × 1920 · 30 fps · exactly 420 frames / 14 seconds · H.264 MP4.

The composition tells one continuous flat 2D story: a stable NAWA core, four
disconnected visual cards, a visible grid transformation, a cohesive system,
then the original Socialize SVG. It follows `PRODUCTION-BRIEF.txt`, the latest
supplied brief. It does not use the earlier raw-footage concept or PDF mockups.

## Edit and render

Requires Node.js, npm, and a local Chromium browser. Dependencies are pinned in
`package-lock.json`. The tested cloud environment uses Node 24 and
`/usr/bin/chromium`.

```sh
npm ci --cache /workspace/.npm-cache --no-audit --no-fund
npm run typecheck
npm run studio
```

From this project directory:

```sh
node scripts/render-frames.mjs
npm run render
python3 scripts/verify-video.py
```

Set `REMOTION_BROWSER_EXECUTABLE` for video rendering if Chromium has a
different location; update the still/studio browser path accordingly.
Frame previews are at 1s, 3s, 5.5s, 8.5s, 11s, and 13s. Frame 342 additionally
checks the third scene-five phrase after its reveal completes.

## Source files

- `src/SocializeReel.tsx`: animation, exact Arabic copy, RTL masks, continuous cards.
- `src/NawaMark.tsx`: fictional geometric NAWA lettering.
- `src/Root.tsx`: composition dimensions, frame rate, and duration.
- `public/assets`: original supplied logo and four original KO Sans weights,
  plus generated SFX-only audio.
- `scripts/render_sound_design.py`: original sound effects, no music or samples.

The supplied KO Sans files contain Arabic glyphs and no Latin alphabet. NAWA
is consequently a geometric SVG wordmark, rather than text rendered with a
substitute font. All Arabic is rendered with the supplied KO Sans weights.
The provided KO Sans ellipsis maps to a single dot: the first headline keeps
the exact `…` semantics and draws its three dots as one static inline mark.

The Socialize SVG is used without redrawing or changing its original color
or proportions. All authored graphics use #F8F8DF, #AD350E, and #041D3B.

Scene intervals in frames: 0–59, 60–134, 135–209, 210–299, 300–368, 369–419.
All Arabic blocks are right aligned or centered. The final frame settles by
frame 391 and then holds for 29 frames. The composition begins almost empty,
as requested. The same five graphic blocks persist through the transformation.

Audio is synthesized SFX only, stereo 48 kHz, exactly 14 seconds. Grid clicks
match the four arrival frames 249, 252, 255, and 258. No copyrighted music,
external recordings, generated office footage, or PDF application imagery is
included in the final reel.

The final render uses PNG capture and BT.709 limited-range H.264. Remotion
renders all 420 video frames; FFmpeg copies that video stream and encodes the
original WAV into AAC. This preserves the rendered image stream and avoids
ADTS padding that would otherwise make the file longer than 14 seconds.

No GitHub repository was modified or pushed. This source folder can be placed
in a repository for further editing.
