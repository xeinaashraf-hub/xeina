#!/usr/bin/env python3
"""Socialize Reel 01: original, sparse non-musical sound effects only.

Supersedes the earlier instrumental concept. No music stem, melody, repeated
beat, recording or external sample is used by this renderer. Requires NumPy.
"""
from pathlib import Path
import json
import math
import wave

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'public' / 'assets' / 'sound-design.wav'
RATE = 48000
DURATION = 14.0
COUNT = int(RATE * DURATION)
RNG = np.random.default_rng(145513)
TRACK = np.zeros((COUNT, 2), dtype=float)
CUES = []


def lowpass(samples, coefficient):
    output = np.zeros_like(samples)
    for i in range(1, len(samples)):
        output[i] = coefficient * output[i - 1] + (1 - coefficient) * samples[i]
    return output


def envelope(t, length, attack=.004, release=.050):
    return np.minimum(1.0, t / attack) * np.minimum(1.0, (length - t) / release)


def impact(length=.28, low=52, body=125):
    t = np.arange(round(length * RATE)) / RATE
    phase = 2 * np.pi * (low * t + 15 / 32 * (1 - np.exp(-32 * t)))
    sound = (.68 * np.sin(phase) * np.exp(-16 * t)
             + .21 * np.sin(2 * np.pi * body * t) * np.exp(-28 * t))
    air = lowpass(RNG.normal(0, 1, len(t)), .75)
    sound += .08 * air * np.exp(-55 * t)
    return sound * envelope(t, length, .003, .055)


def whoosh(length=.27):
    t = np.arange(round(length * RATE)) / RATE
    noise = RNG.normal(0, 1, len(t))
    band = lowpass(noise, .94) - lowpass(noise, .995)
    return band * np.sin(np.pi * t / length) ** 2


def soft_click(length=.055, center=590):
    t = np.arange(round(length * RATE)) / RATE
    noise = lowpass(RNG.normal(0, 1, len(t)), .65)
    sound = (.62 * np.sin(2 * np.pi * center * t)
             + .18 * np.sin(2 * np.pi * center * 1.83 * t)
             + .15 * noise)
    return sound * np.exp(-92 * t) * envelope(t, length, .0018, .018)


def airy_rise(length=.60):
    """A moving noise resonance, not a note sequence or musical phrase."""
    t = np.arange(round(length * RATE)) / RATE
    noise = RNG.normal(0, 1, len(t))
    output = np.zeros(len(t))
    freq = 420 + 700 * (t / length) ** 1.3
    # Broad, changing resonance gives the requested gentle tonal impression.
    # Driven by noise only: no periodic oscillator or held musical note.
    radius = .987
    for i in range(2, len(t)):
        output[i] = (2 * radius * math.cos(2 * math.pi * freq[i] / RATE) * output[i - 1]
                     - radius ** 2 * output[i - 2] + .015 * noise[i])
    shape = np.sin(np.pi * t / length) ** 1.6
    return output * shape


def place(sound, time, peak_db, label, pan=0):
    start = round(time * RATE)
    size = min(len(sound), COUNT - start)
    scaled = sound[:size] / max(np.max(np.abs(sound)), 1e-12)
    channel_gains = np.array([math.cos((pan + 1) * math.pi / 4),
                              math.sin((pan + 1) * math.pi / 4)])
    channel_gains /= np.max(channel_gains)
    TRACK[start:start + size] += scaled[:, None] * 10 ** (peak_db / 20) * channel_gains
    CUES.append({'time_seconds':time, 'effect':label,
                 'duration_seconds':size / RATE, 'nominal_peak_dbfs':peak_db})


place(impact(), .55, -18, 'Hook: muted low impact')
place(whoosh(), 2.1, -26, 'Visual cards: very light airy whoosh', -.12)
place(soft_click(center=480), 4.7, -24, 'Problem word: low soft click')
place(airy_rise(), 7.0, -28, 'Transformation: subtle broad noise-resonance rise')
for i, cue in enumerate((8.3, 8.4, 8.5, 8.6)):
    place(soft_click(length=.045, center=690), cue, -27,
          f'Grid alignment: soft snap {i + 1}', -.10 if i % 2 == 0 else .10)
place(impact(length=.24, low=57, body=133), 12.3, -19, 'Socialize logo: clean soft impact')

assert len(TRACK) == 672000 and TRACK.shape[1] == 2
assert np.max(np.abs(TRACK)) < .20
OUT.parent.mkdir(parents=True, exist_ok=True)
pcm = np.round(TRACK * 32767).astype('<i2')
with wave.open(str(OUT), 'wb') as writer:
    writer.setnchannels(2)
    writer.setsampwidth(2)
    writer.setframerate(RATE)
    writer.writeframes(pcm.tobytes())
quantized = pcm.astype(float) / 32768
peak = float(np.max(np.abs(quantized)))
rms = float(np.sqrt(np.mean(quantized ** 2)))
nonzero = np.any(pcm != 0, axis=1)
report = {
    'file':str(OUT), 'sfx_only':True, 'music_used':False,
    'duration_seconds':len(TRACK) / RATE, 'sample_frames':len(TRACK),
    'sample_rate':RATE, 'channels':2, 'pcm_bit_depth':16,
    'sample_peak_dbfs':round(20 * math.log10(peak),2),
    'whole_timeline_rms_dbfs':round(20 * math.log10(rms),2),
    'clipped_samples':int(np.sum(np.abs(pcm.astype(np.int32)) >= 32767)),
    'nonzero_seconds':round(float(nonzero.sum()/RATE),4),
    'cues':CUES,
}
(ROOT/'scripts'/'sound-design-validation.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
