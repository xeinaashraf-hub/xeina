#!/usr/bin/env python3
"""Verify the actual exported file, not source-code timing assumptions."""
import json
import subprocess
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
OUTPUT = ROOT / 'output/socialize-reel-01.mp4'


def execute(command):
    return subprocess.run(command, check=True, capture_output=True, text=True)


result = execute(['ffprobe', '-v', 'error', '-show_streams', '-show_format',
                  '-of', 'json', str(OUTPUT)])
data = json.loads(result.stdout)
video = next(s for s in data['streams'] if s['codec_type'] == 'video')
audio = next(s for s in data['streams'] if s['codec_type'] == 'audio')
assert video['codec_name'] == 'h264', video['codec_name']
assert (video['width'], video['height']) == (1080, 1920)
assert video['avg_frame_rate'] == '30/1'
assert int(video['nb_frames']) == 420
assert abs(float(video['duration']) - 14) < 0.001
assert video['pix_fmt'] == 'yuv420p'
assert video['color_space'] == 'bt709'
assert video['color_range'] == 'tv'
assert abs(float(data['format']['duration']) - 14) < 0.001
assert audio['codec_name'] == 'aac'
assert audio['channels'] == 2
assert abs(float(audio['duration']) - 14) < 0.001
execute(['ffmpeg', '-v', 'error', '-i', str(OUTPUT), '-f', 'null', '-'])
# Check decoded audio for finite levels and an actual signal.
stats = execute(['ffmpeg', '-hide_banner', '-i', str(OUTPUT), '-vn', '-af',
                 'volumedetect', '-f', 'null', '-'])
assert 'mean_volume: -inf' not in stats.stderr
assert 'max_volume: -inf' not in stats.stderr
report = {
    'file': OUTPUT.name,
    'resolution': '1080x1920',
    'fps': 30,
    'frames': 420,
    'video_duration_seconds': float(video['duration']),
    'audio_duration_seconds': float(audio['duration']),
    'video_codec': video['codec_name'],
    'audio_codec': audio['codec_name'],
    'audio_sample_rate': int(audio['sample_rate']),
    'channels': audio['channels'],
    'full_decode': 'passed',
    'audio_signal': 'passed',
    'visual_frames_reviewed': [30, 90, 165, 255, 330, 342, 390],
    'full_probe': data,
}
(ROOT / 'output/verification.json').write_text(json.dumps(report, indent=2) + '\n')
print('PASS: H.264, 1080x1920, 30fps, 420 frames, 14 seconds, stereo AAC, full decode, audio signal.')
