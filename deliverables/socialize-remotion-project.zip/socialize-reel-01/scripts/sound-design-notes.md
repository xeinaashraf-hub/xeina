# Sound design — current production brief

Use `public/assets/sound-design.wav` at unity gain on the 14-second timeline. This replaces the earlier instrumental concept. The current soundtrack contains **sound effects only**: no music, rhythmic bed, melody, voice, external recordings, or downloaded samples.

Original synthesized cues follow section 13 of the production brief: muted hook impact at 0.55 s; light air at 2.1 s; low click at 4.7 s; a broad rising noise resonance at 7.0 s; grid snaps at 8.3, 8.4, 8.5, and 8.6 s; clean logo impact at 12.3 s. The grid snaps align with the actual card landing frames 249, 252, 255, and 258 at 30 fps, after each card's 18-frame easing arrival. Each cue has a soft attack and short fade, leaving silence between editorial beats. The riser is filtered noise only, with no held note or note sequence.

Recreate with `python3 scripts/render_sound_design.py` from the Remotion folder. Requires NumPy. The WAV is stereo 48 kHz, signed 16-bit PCM, exactly 672,000 sample frames / 14.000 seconds. Quantized peak, RMS, clipping and exact cue times are saved in `scripts/sound-design-validation.json`.

Listen against the animation before publishing to confirm that the low impacts remain subtle and that the four grid clicks match the card placements. This track intentionally retains generous headroom and silence; no loudness normalization or music-bed compression is applied.
