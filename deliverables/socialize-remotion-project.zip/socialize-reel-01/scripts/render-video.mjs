import {bundle} from '@remotion/bundler';
import {openBrowser, renderMedia, selectComposition} from '@remotion/renderer';
import {mkdir} from 'node:fs/promises';
import {spawnSync} from 'node:child_process';
import path from 'node:path';

const root = process.cwd();
const browserExecutable = process.env.REMOTION_BROWSER_EXECUTABLE || '/usr/bin/chromium';
await mkdir('.cache', {recursive: true});
await mkdir('output', {recursive: true});
const serveUrl = await bundle({entryPoint: path.join(root, 'src/index.ts'),
  outDir: path.join(root, '.cache/bundle')});
const browser = await openBrowser('chrome', {browserExecutable});
const master = path.join(root, '.cache/socialize-remotion-master.mp4');
try {
  const composition = await selectComposition({serveUrl, id: 'SocializeReel01',
    puppeteerInstance: browser});
  let last = -1;
  await renderMedia({serveUrl, composition, puppeteerInstance: browser,
    outputLocation: master, codec: 'h264', crf: 16, concurrency: 4,
    pixelFormat: 'yuv420p', colorSpace: 'bt709', imageFormat: 'png',
    // Studio plays the Audio component. Mux its exact original WAV separately,
    // avoiding Remotion ADTS padding that otherwise lengthens the container.
    muted: true,
    onProgress: ({progress}) => {
      const decile = Math.floor(progress * 10);
      if (decile !== last) {last = decile; console.log(`Remotion render ${decile * 10}%`);}
    },
  });
} finally {
  await browser.close({silent: true});
}
const output = path.join(root, 'output/socialize-reel-01.mp4');
const mux = spawnSync('ffmpeg', ['-hide_banner', '-loglevel', 'error', '-y',
  '-i', master, '-i', path.join(root, 'public/assets/sound-design.wav'),
  '-map', '0:v:0', '-map', '1:a:0', '-c:v', 'copy', '-c:a', 'aac',
  '-b:a', '192k', '-ar', '48000', '-t', '14', '-movflags', '+faststart', output],
  {stdio: 'inherit'});
if (mux.error) throw mux.error;
if (mux.status !== 0) throw new Error(`FFmpeg audio mux failed: ${mux.status}`);
console.log(`Rendered: ${output}`);
