import {bundle} from '@remotion/bundler';
import {openBrowser, renderStill, selectComposition} from '@remotion/renderer';
import {mkdir} from 'node:fs/promises';
import path from 'node:path';

const root = process.cwd();
const serveUrl = await bundle({entryPoint: path.join(root, 'src/index.ts'),
  outDir: path.join(root, '.cache/bundle')});
const browser = await openBrowser('chrome', {browserExecutable: '/usr/bin/chromium'});
try {
  const composition = await selectComposition({serveUrl, id: 'SocializeReel01',
    puppeteerInstance: browser});
  await mkdir('output/frames', {recursive: true});
  const requested = process.argv.slice(2).map(Number);
  for (const frame of requested.length ? requested : [30, 90, 165, 255, 330, 390]) {
    await renderStill({serveUrl, composition, frame,
      puppeteerInstance: browser, imageFormat: 'png',
      output: `output/frames/frame-${frame}.png`,
      onBrowserLog: (log) => {if (log.type === 'error') console.error(log.text);}});
    console.log(`Rendered QC frame ${frame} (${frame / 30}s)`);
  }
} finally {
  await browser.close({silent: true});
}
