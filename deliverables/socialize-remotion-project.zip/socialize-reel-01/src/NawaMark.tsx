import React, {type CSSProperties} from 'react';

export type NawaMarkProps = {
  height: number;
  color: string;
  weight?: number;
  style?: CSSProperties;
};

/** Fictional NAWA lettering, drawn as geometry rather than a font or symbol. */
export const NawaMark: React.FC<NawaMarkProps> = ({
  height,
  color,
  weight = 600,
  style,
}) => {
  const strokeWidth = 4 + (Math.min(700, Math.max(400, weight)) - 400) / 100;

  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      viewBox="0 0 242 68"
      width={(height * 242) / 68}
      height={height}
      role="img"
      aria-label="NAWA"
      style={{display: 'block', overflow: 'visible', ...style}}
    >
      <g
        fill="none"
        stroke={color}
        strokeWidth={strokeWidth}
        strokeLinecap="butt"
        strokeLinejoin="miter"
        strokeMiterlimit={3}
      >
        <path d="M9 57V11L48 57V11" />
        <path d="M64 57L84 11L104 57M71.83 39H96.17" />
        <path d="M120 11L133 57L148 22L163 57L176 11" />
        <path d="M192 57L212 11L232 57M199.83 39H224.17" />
      </g>
    </svg>
  );
};

export default NawaMark;
