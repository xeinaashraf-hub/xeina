import React, {CSSProperties, useEffect, useState} from 'react';
import {
  AbsoluteFill, Audio, Img, continueRender, delayRender, interpolate,
  staticFile, useCurrentFrame,
} from 'remotion';
import {NawaMark} from './NawaMark';

const C = {paper: '#F8F8DF', orange: '#AD350E', navy: '#041D3B'};
const clamp = (v: number) => Math.min(1, Math.max(0, v));
const quint = (v: number) => 1 - Math.pow(1 - clamp(v), 5);
const cubic = (v: number) => {
  const t = clamp(v);
  return t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2;
};
const phase = (f: number, start: number, duration = 9) => clamp((f - start) / duration);
const lerp = (a: number, b: number, t: number) => a + (b - a) * t;

const BASE: CSSProperties = {fontFamily: 'KO Sans', color: C.navy};

const useFonts = () => {
  const [handle] = useState(() => delayRender('Loading original KO Sans fonts'));
  useEffect(() => {
    let active = true;
    const definitions = [
      ['Regular', '400'], ['Medium', '500'], ['SemiBold', '600'], ['Bold', '700'],
    ];
    Promise.all(definitions.map(async ([name, weight]) => {
      const font = new FontFace('KO Sans', `url("${staticFile(`assets/KOSans-${name}.otf`)}")`,
        {weight, style: 'normal'});
      document.fonts.add(await font.load());
    })).then(async () => {
      await document.fonts.ready;
      if (active) continueRender(handle);
    }).catch((error) => {throw error;});
    return () => {active = false;};
  }, [handle]);
};

const Reveal: React.FC<{
  frame: number; start: number; end?: number; children: React.ReactNode;
  style?: CSSProperties; centered?: boolean;
}> = ({frame, start, end, children, style, centered = false}) => {
  const p = quint(phase(frame, start));
  const out = end === undefined ? 1 : 1 - cubic(phase(frame, end, 8));
  return <div data-arabic="true" dir="rtl" style={{
    position: 'absolute', left: 110, right: 126, top: 220,
    direction: 'rtl', textAlign: centered ? 'center' : 'right',
    fontSize: 92, fontWeight: 700, lineHeight: 1.06,
    whiteSpace: 'normal', wordSpacing: 2, opacity: p * out,
    // KO Sans diacritics extend above its tight line box. Expand vertical mask.
    clipPath: `inset(-32px 0 -38px ${(1 - p) * 100}%)`,
    transform: `translateX(${28 * (1 - p)}px)`,
    ...style,
  }}>{children}</div>;
};

type Box = {x: number; y: number; w: number; h: number; r: number};
const INITIAL: Box[] = [
  {x: 110, y: 790, w: 288, h: 310, r: -3},
  {x: 694, y: 810, w: 272, h: 224, r: 3},
  {x: 106, y: 1255, w: 345, h: 215, r: 2},
  {x: 713, y: 1196, w: 253, h: 304, r: -2},
];
const DISCONNECTED: Box[] = [
  {x: 128, y: 858, w: 304, h: 325, r: -3},
  {x: 662, y: 862, w: 294, h: 250, r: 3},
  {x: 107, y: 1201, w: 386, h: 250, r: 2},
  {x: 693, y: 1160, w: 275, h: 332, r: -2},
];
const ORGANIZED: Box[] = [
  {x: 524, y: 747, w: 452, h: 276, r: 0},
  {x: 104, y: 1043, w: 254, h: 392, r: 0},
  {x: 378, y: 1043, w: 288, h: 392, r: 0},
  {x: 686, y: 1043, w: 290, h: 392, r: 0},
];
const mixBox = (a: Box, b: Box, p: number): Box => ({
  x: lerp(a.x, b.x, p), y: lerp(a.y, b.y, p),
  w: lerp(a.w, b.w, p), h: lerp(a.h, b.h, p), r: lerp(a.r, b.r, p),
});
const cardBox = (frame: number, index: number) => {
  // The hold at frames 189–194 happens before any grid transformation begins.
  const tension = cubic(phase(frame, 144 + index * 2, 31));
  const fragmented = mixBox(INITIAL[index], DISCONNECTED[index], tension);
  const organized = cubic(phase(frame, 231 + index * 3, 18));
  return {box: mixBox(fragmented, ORGANIZED[index], organized), organized};
};

const Rule: React.FC<{style?: CSSProperties; color?: string}> = ({style, color = C.navy}) =>
  <div style={{position: 'absolute', height: 3, backgroundColor: color, ...style}} />;

const Ellipsis: React.FC = () => <span aria-label="…" style={{
  position: 'relative', display: 'inline-flex', direction: 'ltr',
  gap: 7, width: 44, height: 17, verticalAlign: 'baseline',
  alignItems: 'flex-end', marginRight: 8,
}}>
  {/* Supplied KO Sans maps U+2026 to a single-dot glyph; retain exact text semantics. */}
  <span style={{position: 'absolute', opacity: 0}}>…</span>
  {[0, 1, 2].map(i => <span key={i} style={{width: 10, height: 10,
    borderRadius: '50%', backgroundColor: 'currentColor'}} />)}
</span>;

const NawaCore: React.FC<{frame: number}> = ({frame}) => {
  const entrance = quint(phase(frame, 10, 10));
  const organized = cubic(phase(frame, 225, 18));
  const box = mixBox({x: 420, y: 1050, w: 240, h: 240, r: 0},
    {x: 104, y: 747, w: 400, h: 276, r: 0}, organized);
  return <div data-role="stable-brand-core" style={{
    position: 'absolute', left: box.x, top: box.y, width: box.w, height: box.h,
    background: C.paper, border: `3px solid ${C.navy}`, borderRadius: 8,
    opacity: entrance, transform: `scale(${lerp(0.97, 1, entrance)})`,
    display: 'flex', alignItems: 'center', justifyContent: 'center',
  }}>
    <NawaMark height={lerp(44, 69, organized)} color={C.navy} weight={600} />
    <Rule color={C.orange} style={{right: 28, bottom: 31, width: lerp(39, 98, organized)}} />
  </div>;
};

const SystemCard: React.FC<{frame: number; index: number}> = ({frame, index}) => {
  const {box, organized: p} = cardBox(frame, index);
  const enter = quint(phase(frame, 64 + index * 3, 9));
  const offsets = [{x: 0, y: -34}, {x: 34, y: 0}, {x: -34, y: 0}, {x: 0, y: 34}];
  const background = [C.orange, C.paper, C.navy, C.orange][index];
  const textColor = index === 2 ? C.paper : C.navy;
  const initialSize = [69, 35, 57, 46][index];
  const finalSize = [66, 42, 48, 48][index];
  const finalBackground = [C.orange, C.paper, C.paper, C.navy][index];
  const blockStyle: CSSProperties = {
    position: 'absolute', left: box.x, top: box.y, width: box.w, height: box.h,
    borderRadius: 8, overflow: 'hidden', border: `3px solid ${C.navy}`,
    opacity: enter,
    transform: `translate(${offsets[index].x * (1 - enter)}px,${offsets[index].y * (1 - enter)}px) rotate(${box.r}deg)`,
  };
  return <div data-card={index} style={blockStyle}>
    <div style={{position: 'absolute', inset: 0, backgroundColor: background}} />
    <div style={{position: 'absolute', inset: 0, opacity: p, backgroundColor: finalBackground}} />
    <div style={{position: 'absolute', left: 25, right: 25,
      top: lerp(index === 1 ? 45 : 49, 28, p),
      fontSize: lerp(initialSize, finalSize, p), fontWeight: p > 0.6 ? 700 : [700, 400, 600, 500][index],
      color: p > 0.6 ? (index === 3 ? C.paper : C.navy) : textColor,
      letterSpacing: lerp([0, 4, 2.8, 0.3][index], 0.8, p),
      textAlign: index === 3 ? 'right' : 'left',
    }}><NawaMark height={lerp(initialSize, finalSize, p) * 0.88}
      color={p > 0.6 ? (index === 3 ? C.paper : C.navy) : textColor}
      weight={lerp([700, 400, 600, 500][index], 700, p)}
      style={{marginLeft: index === 3 ? 'auto' : 0}} /></div>
    {/* Graphic content belongs to each persistent card; it reconfigures in place. */}
    {index === 0 && <>
      <Rule color={C.navy} style={{left: 26, top: lerp(139, 118, p), width: box.w - 52}} />
      <div style={{position: 'absolute', left: 27, right: 27, bottom: 31,
        display: 'flex', gap: 10, alignItems: 'flex-end'}}>
        {[0, 1, 2, 3, 4, 5].map(i => <div key={i} style={{
          width: 25 + p * 20, height: 11 + (i % 3) * 6,
          background: C.navy, opacity: 0.88,
        }} />)}
      </div>
    </>}
    {index === 1 && <>
      <Rule style={{left: 26, right: 26, top: lerp(126, 92, p)}} />
      <div style={{position: 'absolute', left: 26, right: 26,
        top: lerp(147, 120, p), bottom: 27, display: 'flex',
        gap: lerp(28, 0, p), flexDirection: p > 0.55 ? 'column' : 'row'}}>
        {[C.orange, C.navy, C.paper].map((color, i) => <div key={color} style={{
          flex: 1, backgroundColor: color, border: `2px solid ${C.navy}`,
          minHeight: 25, width: 'auto', opacity: lerp(0.5 + i * 0.15, 1, p),
        }} />)}
      </div>
    </>}
    {index === 2 && <>
      <div style={{position: 'absolute', left: 26, right: 26, top: lerp(119, 106, p),
        height: lerp(48, 162, p), backgroundColor: p > 0.6 ? C.navy : C.paper}} />
      <Rule color={p > 0.6 ? C.orange : C.paper}
        style={{left: 26, width: box.w - 98, bottom: 61}} />
      <Rule color={p > 0.6 ? C.navy : C.paper}
        style={{left: 26, width: box.w - 124, bottom: 38}} />
      <div style={{position: 'absolute', width: 66, height: 66, background: C.orange,
        top: lerp(130, 153, p), left: box.w - 109, opacity: p}} />
    </>}
    {index === 3 && <>
      <div style={{position: 'absolute', left: 26, right: 26, top: lerp(132, 106, p),
        bottom: 86, backgroundColor: C.paper, border: `2px solid ${C.navy}`}} />
      <div style={{position: 'absolute', left: 26, right: 26, bottom: 32,
        height: 33, backgroundColor: p > 0.6 ? C.orange : C.navy}} />
      <div style={{position: 'absolute', left: 48, top: lerp(154, 135, p),
        width: lerp(24, 87, p), height: lerp(77, 123, p), background: C.orange}} />
    </>}
  </div>;
};

const EditorialGrid: React.FC<{frame: number}> = ({frame}) => {
  const p = quint(phase(frame, 213, 12));
  return <svg width={880} height={742} viewBox="0 0 880 742" style={{
    position: 'absolute', left: 100, top: 723, opacity: 0.2 * p,
  }} aria-hidden>
    {Array.from({length: 9}, (_, i) => <line key={`v${i}`} x1={i * 110} y1={0}
      x2={i * 110} y2={742 * quint(phase(frame, 214 + i, 10))}
      stroke={C.navy} strokeWidth={2} />)}
    {[0, 300, 320, 712, 742].map((y, i) => <line key={`h${i}`} x1={880}
      y1={y} x2={880 * (1 - quint(phase(frame, 218 + i, 10)))} y2={y}
      stroke={C.navy} strokeWidth={2} />)}
  </svg>;
};

const TensionFrame: React.FC<{frame: number}> = ({frame}) => {
  const enter = quint(phase(frame, 151, 10));
  const exit = 1 - cubic(phase(frame, 207, 10));
  return <svg width={920} height={720} style={{position: 'absolute', left: 80,
    top: 835, opacity: 0.45 * enter * exit}} aria-hidden>
    {/* Broken registration marks expose the failure to share one bounding grid. */}
    <path d="M52 132 V28 H864 V562 M864 610 V690 H14 V562 M14 510 V186"
      fill="none" stroke={C.navy} strokeWidth={3} pathLength={1}
      strokeDasharray="1" strokeDashoffset={1 - enter} />
    <path d="M20 177 H75 M817 585 H896" fill="none" stroke={C.orange} strokeWidth={4} />
  </svg>;
};

export const SocializeReel: React.FC = () => {
  useFonts();
  const f = useCurrentFrame();
  const paperReveal = quint(phase(f, 60, 12));
  const finale = cubic(phase(f, 369, 12));
  const groupOut = 1 - cubic(phase(f, 369, 12));
  const scene2Camera = f >= 60 && f < 135 ? lerp(1.025, 1, cubic(phase(f, 60, 75))) : 1;
  const systemCamera = f >= 210 && f < 369 ? lerp(1.0, 1.02, cubic(phase(f, 210, 159))) : 1;
  const logoEntrance = quint(phase(f, 375, 10));

  return <AbsoluteFill style={{...BASE, background: C.navy, overflow: 'hidden'}}>
    <Audio src={staticFile('assets/sound-design.wav')} volume={1} />
    <AbsoluteFill style={{background: C.paper,
      clipPath: `inset(0 0 0 ${(1 - paperReveal) * 100}%)`}} />

    {/* The warm strip is a visual baseline that later becomes the system's field. */}
    <div style={{position: 'absolute', left: 0, right: 0, bottom: 0,
      height: f < 210 ? 330 : 440,
      background: C.orange, opacity: paperReveal * (1 - finale),
      transform: `translateY(${44 * (1 - paperReveal)}px)`}} />

    <div style={{position: 'absolute', right: 108, top: 172, height: 4,
      background: C.orange, width: 110 * quint(phase(f, 0, 8)),
      opacity: f < 60 ? 1 : 0}} />

    {f < 72 && <>
      <Reveal frame={f} start={4} end={58} style={{top: 240, fontSize: 94, color: C.paper}}>
        براندك ممتاز<Ellipsis />
      </Reveal>
      <Reveal frame={f} start={17} end={58}
        style={{top: 367, fontSize: 102, color: C.orange}}>
        بس هل شكله<br />يبين هالشي؟
      </Reveal>
    </>}
    {f >= 60 && f < 143 && <Reveal frame={f} start={65} end={132}
      style={{top: 220, fontSize: 88, fontWeight: 600}}>
      أحيانًا المشكلة<br /><span style={{color: C.orange}}>مو في البراند.</span>
    </Reveal>}
    {f >= 135 && f < 218 && <>
      <Reveal frame={f} start={140} end={205}
        style={{top: 211, fontSize: 48, fontWeight: 500, color: C.orange}}>
        المشكلة؟
      </Reveal>
      <Reveal frame={f} start={148} end={205} style={{top: 303, fontSize: 92}}>
        <span style={{color: f < 173 ? C.orange : C.navy}}>الصورة</span> اللي<br />تظهر للعميل.
      </Reveal>
    </>}
    {f >= 210 && f < 267 && <Reveal frame={f} start={214} end={247} centered
      style={{top: 252, fontSize: 91, color: C.orange, fontWeight: 600}}>
      وهنا يبدأ الفرق.
    </Reveal>}
    {f >= 300 && f < 381 && <>
      <Reveal frame={f} start={301} end={368}
        style={{top: 218, fontSize: 88, fontWeight: 600}}>هوية واضحة.</Reveal>
      <Reveal frame={f} start={315} end={368}
        style={{top: 329, fontSize: 88, fontWeight: 600}}>متناسقة.</Reveal>
      <Reveal frame={f} start={328} end={368}
        style={{top: 440, fontSize: 72, fontWeight: 600}}>
        وتعكس <span style={{color: C.orange}}>مستوى البراند.</span>
      </Reveal>
    </>}

    <div style={{position: 'absolute', inset: 0, opacity: groupOut,
      transformOrigin: '540px 1090px',
      transform: `translateY(${-36 * (1 - groupOut)}px) scale(${scene2Camera * systemCamera})`}}>
      <EditorialGrid frame={f} />
      <TensionFrame frame={f} />
      {INITIAL.map((_, i) => <SystemCard key={i} index={i} frame={f} />)}
      <NawaCore frame={f} />
    </div>

    <AbsoluteFill style={{background: C.navy,
      clipPath: `inset(0 0 ${100 * (1 - finale)}% 0)`}} />
    {f >= 369 && <>
      <Img src={staticFile('assets/PRIMARY LOGO.svg')} data-role="actual-socialize-logo"
        style={{position: 'absolute', left: 290, top: 727, width: 500, height: 'auto',
          opacity: logoEntrance, transformOrigin: 'center',
          transform: `translateY(${24 * (1 - logoEntrance)}px) scale(${lerp(0.97, 1, logoEntrance)})`}} />
      <Reveal frame={f} start={382} centered style={{left: 104, right: 104, top: 1021, fontSize: 52,
        fontWeight: 600, lineHeight: 1.08, color: C.paper}}>
        نبني هوية تعكس مستوى براندك.
      </Reveal>
    </>}
  </AbsoluteFill>;
};
