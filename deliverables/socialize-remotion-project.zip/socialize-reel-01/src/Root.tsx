import React from 'react';
import {Composition} from 'remotion';
import {SocializeReel} from './SocializeReel';

export const Root: React.FC = () => (
  <Composition id="SocializeReel01" component={SocializeReel}
    durationInFrames={420} fps={30} width={1080} height={1920} />
);
